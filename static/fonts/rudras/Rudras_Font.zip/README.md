#Rudras
A font based on Rudra no Hihou, and old SNES game by
 Square.
This work is licensed under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

Author: Zelda Hessler
Publish Date: November 9, 2016

